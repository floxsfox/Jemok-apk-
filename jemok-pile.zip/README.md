# Jemok Pile

Aplikasi Android (Kotlin + Jetpack Compose) untuk menyimpan video dan audio dari tautan:
YouTube, SoundCloud, TikTok, X, Instagram, Facebook, Spotify (satu lagu, dicocokkan ke YouTube),
dan ribuan situs lain yang didukung yt-dlp.

## Cara build lewat GitHub (dari HP)
1. Buat repo baru di github.com, lalu Add file > Upload files > unggah `jemok-pile.zip`.
2. Add file > Create new file, ketik nama `.github/workflows/build-dari-zip.yml`,
   isi dengan file `build-dari-zip.yml`, lalu Commit.
3. Tab Actions > "Build APK dari ZIP" > Run workflow (atau otomatis jalan saat commit).
4. Setelah hijau, buka run-nya, bagian Artifacts, unduh `JemokPile-APK`, ekstrak, pasang APK-nya.

APK ditandatangani dengan `jemokpile.keystore` yang tetap, jadi versi baru bisa menimpa versi lama.

## Catatan
- Hanya arm64 (HP modern). HP 32-bit: ubah `abiFilters` di `app/build.gradle.kts`.
- Hasil unduhan: `Movies/Jemok Pile` (video) dan `Music/Jemok Pile` (audio).
- Kalau unduhan mendadak gagal di satu situs, buka Pengaturan > Perbarui sekarang.
- Instagram dan konten privat sering minta login; tautan publik biasanya aman.
