package com.jemokpile.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jemokpile.app.data.Engine
import com.jemokpile.app.data.MediaInfo
import com.jemokpile.app.data.extractUrl
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

sealed interface Look {
    data object Idle : Look
    data object Loading : Look
    data class Ready(val info: MediaInfo) : Look
    data class Fail(val msg: String) : Look
}

class MainViewModel : ViewModel() {
    var input by mutableStateOf("")
    var look by mutableStateOf<Look>(Look.Idle)
        private set

    private var job: Job? = null

    fun analyze() {
        val url = extractUrl(input)
        if (url == null) {
            look = Look.Fail("Tempel tautan lengkap yang diawali https://")
            return
        }
        job?.cancel()
        Engine.cancelFetch()
        look = Look.Loading
        job = viewModelScope.launch {
            val r = runCatching { Engine.fetchInfo(url) }
            if (!isActive) return@launch
            look = r.fold(
                onSuccess = { Look.Ready(it) },
                onFailure = { Look.Fail(Engine.friendly(it)) }
            )
        }
    }

    fun reset() {
        job?.cancel()
        Engine.cancelFetch()
        look = Look.Idle
    }
}
