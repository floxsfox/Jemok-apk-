package com.jemokpile.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.jemokpile.app.data.Engine

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(Engine.CHANNEL_ID, "Unduhan", NotificationManager.IMPORTANCE_LOW)
        )
        Engine.init(this)
    }
}
