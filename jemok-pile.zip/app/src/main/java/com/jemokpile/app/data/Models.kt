package com.jemokpile.app.data

import android.net.Uri
import org.json.JSONObject

enum class Platform(val label: String, val color: Long) {
    YOUTUBE("YouTube", 0xFFFF6B6B),
    SPOTIFY("Spotify", 0xFF5BE3A0),
    SOUNDCLOUD("SoundCloud", 0xFFFF9F4A),
    TIKTOK("TikTok", 0xFF4FE0E6),
    X("X", 0xFFC9CFE6),
    INSTAGRAM("Instagram", 0xFFF08AD8),
    FACEBOOK("Facebook", 0xFF7FA6FF),
    OTHER("Situs lain", 0xFFB9C1E0);

    companion object {
        fun detect(url: String): Platform {
            val h = (Uri.parse(url).host ?: "").lowercase().removePrefix("www.")
            return when {
                h.endsWith("youtube.com") || h == "youtu.be" || h.endsWith("youtube-nocookie.com") -> YOUTUBE
                h.endsWith("spotify.com") || h.endsWith("spotify.link") -> SPOTIFY
                h.endsWith("soundcloud.com") || h == "snd.sc" -> SOUNDCLOUD
                h.endsWith("tiktok.com") -> TIKTOK
                h == "x.com" || h.endsWith(".x.com") || h.endsWith("twitter.com") || h == "t.co" -> X
                h.endsWith("instagram.com") -> INSTAGRAM
                h.endsWith("facebook.com") || h == "fb.watch" || h.endsWith("fb.com") -> FACEBOOK
                else -> OTHER
            }
        }
    }
}

enum class Mode { VIDEO, AUDIO }

enum class Status { WAITING, RUNNING, DONE, FAILED, CANCELED }

enum class Boot { LOADING, READY, ERROR }

/** Hasil pemeriksaan tautan, ditampilkan sebelum pengguna memilih format. */
data class MediaInfo(
    val target: String,
    val title: String,
    val creator: String,
    val seconds: Long,
    val thumb: String?,
    val platform: Platform,
    val audioOnly: Boolean,
    val note: String? = null,
    val fileBase: String? = null
)

data class Settings(
    val mode: Mode = Mode.VIDEO,
    val videoHeight: Int = 0,
    val audioFormat: String = "mp3",
    val embedTags: Boolean = true,
    val theme: Int = 0,
    val nightly: Boolean = false
)

/** Satu baris di "tumpukan" unduhan. */
data class Entry(
    val id: String,
    val title: String,
    val creator: String,
    val thumb: String?,
    val platform: Platform,
    val mode: Mode,
    val target: String,
    val quality: String,
    val videoHeight: Int,
    val audioFormat: String,
    val embedTags: Boolean,
    val fileBase: String? = null,
    val status: Status = Status.WAITING,
    val progress: Float = 0f,
    val note: String = "",
    val resultUri: String? = null,
    val resultMime: String? = null,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("creator", creator)
        put("thumb", thumb ?: "")
        put("platform", platform.name)
        put("mode", mode.name)
        put("target", target)
        put("quality", quality)
        put("h", videoHeight)
        put("fmt", audioFormat)
        put("tags", embedTags)
        put("base", fileBase ?: "")
        put("status", status.name)
        put("progress", progress.toDouble())
        put("uri", resultUri ?: "")
        put("mime", resultMime ?: "")
        put("error", error ?: "")
        put("at", createdAt)
    }

    companion object {
        fun fromJson(o: JSONObject): Entry = Entry(
            id = o.getString("id"),
            title = o.optString("title"),
            creator = o.optString("creator"),
            thumb = o.optString("thumb").ifEmpty { null },
            platform = Platform.entries.firstOrNull { it.name == o.optString("platform") } ?: Platform.OTHER,
            mode = if (o.optString("mode") == "AUDIO") Mode.AUDIO else Mode.VIDEO,
            target = o.optString("target"),
            quality = o.optString("quality"),
            videoHeight = o.optInt("h", 0),
            audioFormat = o.optString("fmt", "mp3"),
            embedTags = o.optBoolean("tags", true),
            fileBase = o.optString("base").ifEmpty { null },
            status = Status.entries.firstOrNull { it.name == o.optString("status") } ?: Status.FAILED,
            progress = o.optDouble("progress", 0.0).toFloat(),
            resultUri = o.optString("uri").ifEmpty { null },
            resultMime = o.optString("mime").ifEmpty { null },
            error = o.optString("error").ifEmpty { null },
            createdAt = o.optLong("at", 0L)
        )
    }
}
