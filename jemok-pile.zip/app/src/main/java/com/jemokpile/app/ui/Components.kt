package com.jemokpile.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Penanda platform: blok warna solid dengan teks tinta. */
@Composable
fun Tag(label: String, color: Color) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color)
            .padding(horizontal = 9.dp, vertical = 4.dp)
    ) {
        Text(label, color = Color(0xFF101A3D), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** Label kecil beroutline, mis. kualitas "720p". */
@Composable
fun Mini(label: String) {
    val jp = LocalJp.current
    val shape = RoundedCornerShape(8.dp)
    Box(
        Modifier
            .clip(shape)
            .border(1.5.dp, jp.line, shape)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = jp.textDim, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun MarkerButton(
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val jp = LocalJp.current
    Box(
        modifier
            .height(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (enabled) jp.marker else jp.sheetHi)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 22.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            fontFamily = Display,
            fontSize = 15.sp,
            color = if (enabled) jp.onMarker else jp.textDim
        )
    }
}

@Composable
fun TextAction(label: String, color: Color, onClick: () -> Unit) {
    Text(
        label,
        color = color,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 14.dp)
    )
}

/** Pilihan tunggal berbentuk kapsul (kualitas, format, tema). */
@Composable
fun Pick(label: String, on: Boolean, onClick: () -> Unit) {
    val jp = LocalJp.current
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier
            .heightIn(min = 44.dp)
            .clip(shape)
            .background(if (on) jp.marker else Color.Transparent)
            .border(1.5.dp, if (on) jp.marker else jp.line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (on) jp.onMarker else jp.text,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
            fontSize = 15.sp
        )
    }
}

/** Dua atau tiga pilihan selebar layar, mis. Video / Audio. */
@Composable
fun Segment(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val jp = LocalJp.current
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(jp.sheetHi)
            .padding(4.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(11.dp))
                    .background(if (on) jp.marker else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    color = if (on) jp.onMarker else jp.text,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun Bar(progress: Float, modifier: Modifier = Modifier, height: Dp = 8.dp) {
    val jp = LocalJp.current
    val shape = RoundedCornerShape(height)
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(shape)
            .background(jp.sheetHi)
    ) {
        Box(
            Modifier
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .fillMaxHeight()
                .clip(shape)
                .background(jp.marker)
        )
    }
}

/** Judul kelompok pengaturan + isinya. */
@Composable
fun Group(title: String, content: @Composable () -> Unit) {
    val jp = LocalJp.current
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = jp.textDim, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        content()
    }
}
