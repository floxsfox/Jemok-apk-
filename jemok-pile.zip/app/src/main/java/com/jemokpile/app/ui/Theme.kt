package com.jemokpile.app.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat
import com.jemokpile.app.R

/**
 * Palet: indigo tinta + stabilo kuning. Kuning dipakai hanya untuk hal yang bisa
 * ditekan atau sedang aktif. Warna platform (YouTube, TikTok, dst.) jadi penanda
 * di tiap unduhan, bukan dekorasi.
 */
@Immutable
class Jp(
    val bg: Color,
    val sheet: Color,
    val sheetHi: Color,
    val line: Color,
    val text: Color,
    val textDim: Color,
    val marker: Color,
    val onMarker: Color,
    val ok: Color,
    val bad: Color
)

val DarkJp = Jp(
    bg = Color(0xFF101A3D),
    sheet = Color(0xFF18235A),
    sheetHi = Color(0xFF223070),
    line = Color(0xFF34448A),
    text = Color(0xFFEEF1FB),
    textDim = Color(0xFFA3AED6),
    marker = Color(0xFFFFD84A),
    onMarker = Color(0xFF101A3D),
    ok = Color(0xFF6FE3A8),
    bad = Color(0xFFFF8A8A)
)

val LightJp = Jp(
    bg = Color(0xFFEEF1FB),
    sheet = Color(0xFFFFFFFF),
    sheetHi = Color(0xFFE2E7F7),
    line = Color(0xFFC3CCEA),
    text = Color(0xFF101A3D),
    textDim = Color(0xFF55618F),
    marker = Color(0xFFFFD84A),
    onMarker = Color(0xFF101A3D),
    ok = Color(0xFF15803D),
    bad = Color(0xFFC62828)
)

val LocalJp = staticCompositionLocalOf { DarkJp }

/** Judul dan tombol: Archivo Black. Teks lain: Atkinson Hyperlegible. */
val Display = FontFamily(Font(R.font.archivo_black, FontWeight.Normal))
val Body = FontFamily(
    Font(R.font.atkinson_regular, FontWeight.Normal),
    Font(R.font.atkinson_bold, FontWeight.Bold)
)

/** mode: 0 ikuti sistem, 1 terang, 2 gelap */
@Composable
fun JemokTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val jp = if (dark) DarkJp else LightJp
    val scheme = if (dark) {
        darkColorScheme(
            primary = jp.marker, onPrimary = jp.onMarker,
            background = jp.bg, onBackground = jp.text,
            surface = jp.sheet, onSurface = jp.text,
            onSurfaceVariant = jp.textDim, outline = jp.line
        )
    } else {
        lightColorScheme(
            primary = jp.marker, onPrimary = jp.onMarker,
            background = jp.bg, onBackground = jp.text,
            surface = jp.sheet, onSurface = jp.text,
            onSurfaceVariant = jp.textDim, outline = jp.line
        )
    }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window ?: return@SideEffect
        val c = WindowCompat.getInsetsController(window, view)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
    }

    CompositionLocalProvider(LocalJp provides jp) {
        MaterialTheme(colorScheme = scheme) {
            ProvideTextStyle(TextStyle(fontFamily = Body, color = jp.text)) {
                content()
            }
        }
    }
}
