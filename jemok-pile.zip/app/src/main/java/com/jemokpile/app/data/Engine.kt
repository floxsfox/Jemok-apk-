package com.jemokpile.app.data

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import com.jemokpile.app.service.DownloadService
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * Otak aplikasi: menyiapkan yt-dlp, memeriksa tautan, menjalankan antrean unduhan,
 * lalu menyimpan hasilnya ke Music/Movies lewat MediaStore (tanpa izin penyimpanan).
 */
object Engine {
    const val CHANNEL_ID = "unduhan"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var app: Application

    private val _boot = MutableStateFlow(Boot.LOADING)
    val boot: StateFlow<Boot> = _boot
    var bootError: String = ""
        private set

    private val _jobs = MutableStateFlow<List<Entry>>(emptyList())
    val jobs: StateFlow<List<Entry>> = _jobs

    private val _settings = MutableStateFlow(Settings())
    val settings: StateFlow<Settings> = _settings

    private val gate = Semaphore(2)
    private val running = ConcurrentHashMap<String, kotlinx.coroutines.Job>()

    @Volatile
    private var infoPid: String? = null

    private val mediaExt = setOf(
        "mp4", "mkv", "webm", "mov", "m4v", "3gp",
        "mp3", "m4a", "opus", "ogg", "aac", "flac", "wav"
    )

    fun init(application: Application) {
        app = application
        Store.init(application)
        _settings.value = Store.loadSettings()
        // Unduhan yang sedang jalan saat aplikasi dimatikan tidak bisa dilanjutkan.
        _jobs.value = Store.loadEntries().map {
            if (it.status == Status.RUNNING || it.status == Status.WAITING)
                it.copy(status = Status.FAILED, error = "Terhenti karena aplikasi ditutup. Tekan Coba lagi.", note = "")
            else it
        }
        scope.launch {
            try {
                YoutubeDL.getInstance().init(application)
                FFmpeg.getInstance().init(application)
                _boot.value = Boot.READY
            } catch (t: Throwable) {
                bootError = "Mesin unduh gagal dimulai: " + (t.message ?: t.javaClass.simpleName)
                _boot.value = Boot.ERROR
            }
        }
    }

    private suspend fun awaitReady() {
        val st = _boot.first { it != Boot.LOADING }
        if (st == Boot.ERROR) throw IllegalStateException(bootError)
    }

    // ------------------------------------------------------------------ pengaturan

    fun updateSettings(f: (Settings) -> Settings) {
        _settings.update(f)
        Store.saveSettings(_settings.value)
    }

    fun version(): String =
        runCatching { YoutubeDL.getInstance().versionName(app) }.getOrNull() ?: "-"

    suspend fun updateEngine(): String = withContext(Dispatchers.IO) {
        try {
            awaitReady()
            val channel = if (_settings.value.nightly) YoutubeDL.UpdateChannel.NIGHTLY
            else YoutubeDL.UpdateChannel.STABLE
            when (YoutubeDL.getInstance().updateYoutubeDL(app, channel)) {
                YoutubeDL.UpdateStatus.DONE -> "Berhasil diperbarui ke ${version()}"
                YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE -> "Sudah versi terbaru (${version()})"
                null -> "Selesai"
            }
        } catch (t: Throwable) {
            "Gagal memperbarui. " + friendly(t)
        }
    }

    // ------------------------------------------------------------------ periksa tautan

    suspend fun fetchInfo(url: String): MediaInfo = withContext(Dispatchers.IO) {
        awaitReady()
        val platform = Platform.detect(url)
        if (platform == Platform.SPOTIFY) return@withContext fetchSpotify(url)
        val j = ytInfo(url)
        val audioOnly = platform == Platform.SOUNDCLOUD || j.str("vcodec") == "none"
        MediaInfo(
            target = url,
            title = j.str("title").ifBlank { j.str("fulltitle") }.ifBlank { "Tanpa judul" },
            creator = firstOf(j, "uploader", "channel", "creator", "uploader_id"),
            seconds = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() },
            thumb = j.str("thumbnail").ifBlank { null },
            platform = platform,
            audioOnly = audioOnly
        )
    }

    fun cancelFetch() {
        infoPid?.let { runCatching { YoutubeDL.getInstance().destroyProcessById(it) } }
    }

    private fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key)

    private fun firstOf(j: JSONObject, vararg keys: String): String =
        keys.map { j.str(it) }.firstOrNull { it.isNotBlank() } ?: ""

    private fun ytInfo(target: String): JSONObject {
        val pid = "info-" + System.nanoTime()
        infoPid = pid
        val req = YoutubeDLRequest(target)
        req.addOption("--dump-json")
        req.addOption("--no-playlist")
        req.addOption("--playlist-items", "1")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", 20)
        val res = YoutubeDL.getInstance().execute(req, pid, false, null)
        infoPid = null
        val line = res.out.lineSequence().firstOrNull { it.trimStart().startsWith("{") }
            ?: throw IllegalStateException("Tidak ada data media dari tautan ini")
        return JSONObject(line)
    }

    /**
     * Spotify memakai DRM, jadi audionya tidak bisa diambil langsung. Kita baca judul + artis
     * dari halaman lagunya, lalu cari lagu yang sama di YouTube dan unduh dari sana.
     */
    private fun fetchSpotify(url: String): MediaInfo {
        val (html, finalUrl) = httpGet(url)
        if (!finalUrl.contains("/track/"))
            throw IllegalArgumentException("Untuk Spotify, tempel tautan satu lagu (track), bukan album atau playlist.")

        val pageTitle = Regex("<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL)
            .find(html)?.groupValues?.get(1)?.let { unescape(it) }
        val song = meta(html, "og:title")
            ?: pageTitle?.substringBefore(" - song")
            ?: throw IllegalStateException("Judul lagu Spotify tidak terbaca")
        val artist = pageTitle?.let { Regex("by (.+?) \\| Spotify").find(it)?.groupValues?.get(1) }
            ?: meta(html, "og:description")
                ?.takeIf { !it.startsWith("Listen", ignoreCase = true) }
                ?.split("·")?.firstOrNull()?.trim()
            ?: ""
        val cover = meta(html, "og:image")

        val query = if (artist.isBlank()) song else "$artist - $song"
        val j = ytInfo("ytsearch1:$query")
        val ytTitle = j.str("title")
        val safe = query.replace(Regex("[\\\\/:*?\"<>|]"), " ").replace(Regex("\\s+"), " ").trim()

        return MediaInfo(
            target = j.str("webpage_url").ifBlank { throw IllegalStateException("Lagu tidak ditemukan di YouTube") },
            title = song,
            creator = artist,
            seconds = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() },
            thumb = cover ?: j.str("thumbnail").ifBlank { null },
            platform = Platform.SPOTIFY,
            audioOnly = true,
            note = "Spotify tidak membolehkan unduhan langsung. Lagu ini dicocokkan ke YouTube: $ytTitle",
            fileBase = safe.ifBlank { null }
        )
    }

    private fun httpGet(url: String): Pair<String, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.setRequestProperty(
            "User-Agent",
            "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
        )
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        try {
            val body = c.inputStream.bufferedReader().use { it.readText() }
            return body to c.url.toString()
        } finally {
            c.disconnect()
        }
    }

    private fun meta(html: String, prop: String): String? {
        val a = Regex("<meta[^>]+property=\"$prop\"[^>]*content=\"([^\"]*)\"", RegexOption.IGNORE_CASE)
        val b = Regex("<meta[^>]+content=\"([^\"]*)\"[^>]*property=\"$prop\"", RegexOption.IGNORE_CASE)
        return (a.find(html) ?: b.find(html))?.groupValues?.get(1)?.let { unescape(it) }?.takeIf { it.isNotBlank() }
    }

    private fun unescape(s: String): String = s
        .replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").trim()

    // ------------------------------------------------------------------ antrean unduhan

    fun enqueue(info: MediaInfo, mode: Mode, height: Int, audioFmt: String, embed: Boolean) {
        val entry = Entry(
            id = UUID.randomUUID().toString().take(8),
            title = info.title,
            creator = info.creator,
            thumb = info.thumb,
            platform = info.platform,
            mode = mode,
            target = info.target,
            quality = if (mode == Mode.VIDEO) (if (height == 0) "Terbaik" else "${height}p") else audioFmt.uppercase(),
            videoHeight = height,
            audioFormat = audioFmt,
            embedTags = embed,
            fileBase = info.fileBase,
            note = "Antre"
        )
        _jobs.update { listOf(entry) + it }
        Store.saveEntries(_jobs.value)
        start(entry.id)
    }

    fun retry(id: String) {
        patch(id, persist = true) { it.copy(status = Status.WAITING, progress = 0f, note = "Antre", error = null) }
        start(id)
    }

    fun cancel(id: String) {
        val cur = _jobs.value.firstOrNull { it.id == id } ?: return
        when (cur.status) {
            Status.RUNNING -> {
                runCatching { YoutubeDL.getInstance().destroyProcessById(id) }
                running[id]?.cancel()
            }
            Status.WAITING -> {
                running[id]?.cancel()
                patch(id, persist = true) { it.copy(status = Status.CANCELED, note = "") }
            }
            else -> Unit
        }
    }

    fun remove(id: String) {
        cancel(id)
        _jobs.update { l -> l.filterNot { it.id == id } }
        Store.saveEntries(_jobs.value)
    }

    fun clearFinished() {
        _jobs.update { l -> l.filterNot { it.status == Status.DONE || it.status == Status.CANCELED } }
        Store.saveEntries(_jobs.value)
    }

    private fun patch(id: String, persist: Boolean = false, f: (Entry) -> Entry) {
        _jobs.update { list -> list.map { if (it.id == id) f(it) else it } }
        if (persist) Store.saveEntries(_jobs.value)
    }

    private fun start(id: String) {
        runCatching { DownloadService.start(app) }
        val j = scope.launch { gate.withPermit { runJob(id) } }
        running[id] = j
        j.invokeOnCompletion { running.remove(id) }
    }

    private suspend fun runJob(id: String) {
        val e = _jobs.value.firstOrNull { it.id == id } ?: return
        patch(id, persist = true) { it.copy(status = Status.RUNNING, progress = 0f, note = "Menyiapkan", error = null) }
        val tmp = File(app.getExternalFilesDir(null) ?: app.cacheDir, "tmp/$id")
        tmp.deleteRecursively()
        tmp.mkdirs()
        try {
            awaitReady()
            val req = buildRequest(e, tmp)
            var stage = 0
            var stages = if (e.mode == Mode.VIDEO) 2 else 1
            val formatLine = Regex("Downloading \\d+ format\\(s\\): (\\S+)")
            val speedRe = Regex("at\\s+(\\S+/s)")

            YoutubeDL.getInstance().execute(req, id, false) { p, eta, line ->
                formatLine.find(line)?.let { m ->
                    stages = m.groupValues[1].count { it == '+' } + 1
                }
                if (line.contains("Destination:")) stage++
                val note: String? = when {
                    line.contains("[Merger]") -> "Menggabungkan video dan audio"
                    line.contains("[ExtractAudio]") -> "Mengonversi audio"
                    line.contains("[EmbedThumbnail]") || line.contains("[Metadata]") -> "Menyematkan sampul dan tag"
                    line.startsWith("[download]") && p >= 0f -> {
                        val speed = speedRe.find(line)?.groupValues?.get(1)
                        val left = if (eta >= 0) "sisa ${eta / 60}:${"%02d".format(eta % 60)}" else null
                        listOfNotNull(speed, left).joinToString(", ")
                    }
                    else -> null
                }
                val overall = if (p >= 0f) ((maxOf(stage, 1) - 1) + p / 100f) / maxOf(stages, 1) else -1f
                patch(id) { cur ->
                    cur.copy(
                        progress = if (overall >= 0f) maxOf(cur.progress, overall.coerceIn(0f, 0.97f)) else cur.progress,
                        note = note ?: cur.note
                    )
                }
            }

            val out = tmp.walkTopDown()
                .filter { it.isFile && it.extension.lowercase() in mediaExt }
                .maxByOrNull { it.length() }
                ?: throw IllegalStateException("Berkas hasil unduhan tidak ditemukan")

            patch(id) { it.copy(note = "Menyimpan ke penyimpanan", progress = 0.98f) }
            val (uri, mime) = saveToMedia(out, e.mode)
            patch(id, persist = true) {
                it.copy(status = Status.DONE, progress = 1f, note = "", resultUri = uri.toString(), resultMime = mime, error = null)
            }
        } catch (c: YoutubeDL.CanceledException) {
            patch(id, persist = true) { it.copy(status = Status.CANCELED, note = "") }
        } catch (c: CancellationException) {
            patch(id, persist = true) { it.copy(status = Status.CANCELED, note = "") }
            throw c
        } catch (t: Throwable) {
            patch(id, persist = true) { it.copy(status = Status.FAILED, error = friendly(t), note = "") }
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun buildRequest(e: Entry, dir: File): YoutubeDLRequest {
        val name = e.fileBase?.replace("%", "%%") ?: "%(title).120B"
        val r = YoutubeDLRequest(e.target)
        r.addOption("-o", "${dir.absolutePath}/$name.%(ext)s")
        r.addOption("--no-playlist")
        r.addOption("--newline")
        r.addOption("--no-mtime")
        r.addOption("--retries", 5)
        r.addOption("--fragment-retries", 5)
        r.addOption("--socket-timeout", 20)
        r.addOption("--concurrent-fragments", 4)

        if (e.mode == Mode.VIDEO) {
            val cap = if (e.videoHeight > 0) "[height<=${e.videoHeight}]" else ""
            r.addOption("-f", "bv*$cap[ext=mp4]+ba[ext=m4a]/b$cap[ext=mp4]/bv*$cap+ba/b$cap/b")
            r.addOption("--merge-output-format", "mp4")
        } else {
            r.addOption("-f", "bestaudio/best")
            r.addOption("-x")
            r.addOption("--audio-format", e.audioFormat)
            r.addOption("--audio-quality", 0)
            if (e.embedTags) {
                r.addOption("--embed-metadata")
                r.addOption("--embed-thumbnail")
                r.addOption("--convert-thumbnails", "jpg")
            }
        }
        return r
    }

    // ------------------------------------------------------------------ simpan hasil

    private fun saveToMedia(file: File, mode: Mode): Pair<Uri, String> {
        val audio = mode == Mode.AUDIO
        val mime = when (file.extension.lowercase()) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "opus", "ogg" -> "audio/ogg"
            "aac" -> "audio/aac"
            "flac" -> "audio/flac"
            "wav" -> "audio/wav"
            "mp4", "m4v" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "webm" -> if (audio) "audio/webm" else "video/webm"
            "mov" -> "video/quicktime"
            "3gp" -> "video/3gpp"
            else -> if (audio) "audio/mpeg" else "video/mp4"
        }
        val resolver = app.contentResolver
        val attempts = listOf(
            Triple(
                if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                if (audio) "Music/Jemok Pile" else "Movies/Jemok Pile",
                mime
            ),
            Triple(MediaStore.Downloads.EXTERNAL_CONTENT_URI, "Download/Jemok Pile", mime)
        )
        var last: Throwable? = null
        for ((collection, rel, m) in attempts) {
            var uri: Uri? = null
            try {
                val v = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, m)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                uri = resolver.insert(collection, v) ?: error("insert gagal")
                resolver.openOutputStream(uri)!!.use { out ->
                    file.inputStream().use { it.copyTo(out, 1 shl 16) }
                }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
                return uri to m
            } catch (t: Throwable) {
                last = t
                uri?.let { runCatching { resolver.delete(it, null, null) } }
            }
        }
        throw IllegalStateException("Gagal menyimpan berkas: ${last?.message}")
    }

    // ------------------------------------------------------------------ pesan galat

    fun friendly(t: Throwable): String {
        val raw = t.message ?: t.javaClass.simpleName
        val line = raw.lineSequence().map { it.trim() }.lastOrNull { it.startsWith("ERROR") }
            ?: raw.lineSequence().firstOrNull { it.isNotBlank() }
            ?: raw
        val l = line.lowercase()
        return when {
            "unsupported url" in l -> "Situs ini belum didukung, atau tautannya bukan halaman media."
            "requested format is not available" in l -> "Kualitas yang dipilih tidak tersedia. Coba kualitas lain."
            "login" in l || "sign in" in l || "cookies" in l ->
                "Situs meminta login untuk membuka media ini. Coba tautan publik lain."
            "private" in l || "unavailable" in l || "not available" in l || "removed" in l || "deleted" in l ->
                "Media tidak tersedia, sudah dihapus, atau bersifat privat."
            "429" in l || "too many requests" in l -> "Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi."
            "timed out" in l || "name resolution" in l || "unreachable" in l || "urlopen error" in l ||
                "unable to download" in l || "connection" in l ->
                "Gagal terhubung. Periksa koneksi internet lalu coba lagi."
            "ffmpeg" in l || "postprocess" in l || "mutagen" in l ->
                "Konversi gagal. Coba matikan sematan sampul di Pengaturan."
            else -> line.removePrefix("ERROR:").trim().take(200) +
                "\nCoba perbarui yt-dlp di Pengaturan."
        }
    }
}
