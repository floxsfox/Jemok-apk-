package com.jemokpile.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.jemokpile.app.Look
import com.jemokpile.app.MainViewModel
import com.jemokpile.app.data.Boot
import com.jemokpile.app.data.Engine
import com.jemokpile.app.data.Entry
import com.jemokpile.app.data.MediaInfo
import com.jemokpile.app.data.Mode
import com.jemokpile.app.data.Platform
import com.jemokpile.app.data.Settings
import com.jemokpile.app.data.Status
import com.jemokpile.app.data.extractUrl
import com.jemokpile.app.data.fmtTime
import kotlinx.coroutines.launch

private val heights = listOf(0 to "Terbaik", 1080 to "1080p", 720 to "720p", 480 to "480p", 360 to "360p")
private val audioFormats = listOf("mp3" to "MP3", "m4a" to "M4A")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(vm: MainViewModel) {
    val jp = LocalJp.current
    val ctx = LocalContext.current
    val entries by Engine.jobs.collectAsStateWithLifecycle()
    val settings by Engine.settings.collectAsStateWithLifecycle()
    val boot by Engine.boot.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    var showSettings by remember { mutableStateOf(false) }
    val bars = WindowInsets.systemBars.asPaddingValues()
    val look = vm.look

    Box(Modifier.fillMaxSize().background(jp.bg)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = bars.calculateTopPadding() + 16.dp,
                bottom = bars.calculateBottomPadding() + 40.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "head") { Header { showSettings = true } }
            item(key = "slot") {
                Slot(vm) { clipboard.getText()?.text?.let { vm.input = it } }
            }
            if (boot == Boot.LOADING) item(key = "boot") {
                Note("Menyiapkan mesin unduh. Saat pertama dibuka bisa butuh beberapa detik.", false)
            }
            if (boot == Boot.ERROR) item(key = "boot") { Note(Engine.bootError, true) }

            if (entries.isEmpty()) {
                item(key = "empty") { Empty() }
            } else {
                item(key = "pilehead") {
                    PileHead(entries.any { it.status == Status.DONE || it.status == Status.CANCELED }) {
                        Engine.clearFinished()
                    }
                }
                items(entries, key = { it.id }) { e ->
                    EntryCard(
                        e = e,
                        onOpen = { openEntry(ctx, e) },
                        onShare = { shareEntry(ctx, e) },
                        onRetry = { Engine.retry(e.id) },
                        onCancel = { Engine.cancel(e.id) },
                        onRemove = { Engine.remove(e.id) }
                    )
                }
            }
        }
    }

    if (look is Look.Ready) {
        InfoSheet(look.info, settings, onDismiss = { vm.reset() }) { mode, h, fmt ->
            Engine.enqueue(look.info, mode, h, fmt, settings.embedTags)
            vm.input = ""
            vm.reset()
        }
    }
    if (showSettings) SettingsSheet(settings) { showSettings = false }
}

// ---------------------------------------------------------------------- bagian atas

@Composable
private fun Header(onSettings: () -> Unit) {
    val jp = LocalJp.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                "Jemok Pile",
                fontFamily = Display,
                fontSize = 34.sp,
                lineHeight = 36.sp,
                letterSpacing = (-0.5).sp,
                color = jp.text
            )
            Text("Simpan video dan lagu dari tautan.", color = jp.textDim, fontSize = 15.sp)
        }
        TextAction("Pengaturan", jp.text, onSettings)
    }
}

@Composable
private fun Slot(vm: MainViewModel, onPaste: () -> Unit) {
    val jp = LocalJp.current
    val look = vm.look
    val loading = look is Look.Loading
    val platform = extractUrl(vm.input)?.let { Platform.detect(it) }
    val shape = RoundedCornerShape(26.dp)

    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(jp.sheet)
            .border(2.dp, if (vm.input.isNotEmpty()) jp.marker else jp.line, shape)
            .padding(18.dp)
    ) {
        if (platform != null) {
            Tag(platform.label, Color(platform.color))
            Spacer(Modifier.height(10.dp))
        }
        BasicTextField(
            value = vm.input,
            onValueChange = { vm.input = it },
            textStyle = TextStyle(color = jp.text, fontSize = 17.sp, lineHeight = 24.sp, fontFamily = Body),
            cursorBrush = SolidColor(jp.marker),
            maxLines = 3,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp),
            decorationBox = { inner ->
                Box {
                    if (vm.input.isEmpty()) {
                        Text("Tempel tautan video atau lagu", color = jp.textDim, fontSize = 17.sp)
                    }
                    inner()
                }
            }
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (loading) TextAction("Batal", jp.textDim) { vm.reset() }
            else if (vm.input.isEmpty()) TextAction("Tempel", jp.text, onPaste)
            else TextAction("Kosongkan", jp.textDim) { vm.input = ""; vm.reset() }
            Spacer(Modifier.weight(1f))
            MarkerButton(
                label = if (loading) "Memeriksa" else "Cek tautan",
                enabled = !loading && vm.input.isNotBlank()
            ) { vm.analyze() }
        }
        if (look is Look.Fail) {
            Spacer(Modifier.height(6.dp))
            Text(look.msg, color = jp.bad, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun Note(text: String, bad: Boolean) {
    val jp = LocalJp.current
    val shape = RoundedCornerShape(14.dp)
    Text(
        text,
        color = if (bad) jp.bad else jp.textDim,
        fontSize = 14.sp,
        lineHeight = 20.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .border(1.5.dp, if (bad) jp.bad else jp.line, shape)
            .padding(14.dp)
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Empty() {
    val jp = LocalJp.current
    Column(Modifier.fillMaxWidth().padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Tumpukan masih kosong", fontFamily = Display, fontSize = 20.sp, color = jp.text)
        Text(
            "Salin tautan, tempel di atas, lalu pilih format. Atau buka video di aplikasi lain, " +
                "tekan Bagikan, dan pilih Jemok Pile.",
            color = jp.textDim, fontSize = 15.sp, lineHeight = 22.sp
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Platform.entries.forEach { Tag(it.label, Color(it.color)) }
        }
        Text(
            "Spotify hanya untuk satu lagu. Karena Spotify tidak membolehkan unduhan langsung, " +
                "lagunya dicari di YouTube lalu diunduh dari sana.",
            color = jp.textDim, fontSize = 13.sp, lineHeight = 19.sp
        )
    }
}

@Composable
private fun PileHead(hasFinished: Boolean, onClear: () -> Unit) {
    val jp = LocalJp.current
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Tumpukan", fontFamily = Display, fontSize = 20.sp, color = jp.text, modifier = Modifier.weight(1f))
        if (hasFinished) TextAction("Bersihkan yang selesai", jp.textDim, onClear)
    }
}

// ---------------------------------------------------------------------- kartu unduhan

@Composable
private fun EntryCard(
    e: Entry,
    onOpen: () -> Unit,
    onShare: () -> Unit,
    onRetry: () -> Unit,
    onCancel: () -> Unit,
    onRemove: () -> Unit
) {
    val jp = LocalJp.current
    val shape = RoundedCornerShape(18.dp)
    val p by animateFloatAsState(e.progress, label = "progress")

    Row(
        Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .clip(shape)
            .background(jp.sheet)
            .border(1.5.dp, jp.line, shape)
    ) {
        Box(Modifier.width(7.dp).fillMaxHeight().background(Color(e.platform.color)))
        Column(Modifier.weight(1f).padding(start = 14.dp, end = 8.dp, top = 14.dp, bottom = 6.dp)) {
            Row(Modifier.padding(end = 6.dp)) {
                Thumb(e)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        e.title,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        lineHeight = 20.sp,
                        color = jp.text
                    )
                    if (e.creator.isNotBlank()) {
                        Text(e.creator, maxLines = 1, overflow = TextOverflow.Ellipsis, color = jp.textDim, fontSize = 13.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            when (e.status) {
                Status.WAITING, Status.RUNNING -> {
                    Bar(p, Modifier.padding(end = 6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (e.status == Status.WAITING) "Antre" else "${(p * 100).toInt()}%",
                            fontWeight = FontWeight.Bold, fontSize = 13.sp, color = jp.text
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            e.note,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = jp.textDim, fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextAction("Batal", jp.textDim, onCancel)
                    }
                }
                Status.DONE -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Selesai", color = jp.ok, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(Modifier.width(8.dp))
                    Mini(e.quality)
                    Spacer(Modifier.weight(1f))
                    TextAction("Buka", jp.text, onOpen)
                    TextAction("Bagikan", jp.text, onShare)
                    TextAction("Hapus", jp.textDim, onRemove)
                }
                Status.FAILED -> {
                    Text(
                        e.error ?: "Gagal",
                        color = jp.bad, fontSize = 13.sp, lineHeight = 18.sp,
                        maxLines = 4, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(end = 6.dp)
                    )
                    Row {
                        TextAction("Coba lagi", jp.text, onRetry)
                        TextAction("Hapus", jp.textDim, onRemove)
                    }
                }
                Status.CANCELED -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Dibatalkan", color = jp.textDim, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                    TextAction("Ulangi", jp.text, onRetry)
                    TextAction("Hapus", jp.textDim, onRemove)
                }
            }
        }
    }
}

@Composable
private fun Thumb(e: Entry) {
    val jp = LocalJp.current
    Box(
        Modifier.size(64.dp).clip(RoundedCornerShape(12.dp)).background(jp.sheetHi),
        contentAlignment = Alignment.Center
    ) {
        if (e.thumb != null) {
            AsyncImage(
                model = e.thumb,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(e.platform.label.take(1), fontFamily = Display, fontSize = 22.sp, color = jp.textDim)
        }
    }
}

// ---------------------------------------------------------------------- sheet pilih format

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun InfoSheet(
    info: MediaInfo,
    s: Settings,
    onDismiss: () -> Unit,
    onGo: (Mode, Int, String) -> Unit
) {
    val jp = LocalJp.current
    var mode by remember { mutableStateOf(if (info.audioOnly) Mode.AUDIO else s.mode) }
    var height by remember { mutableIntStateOf(s.videoHeight) }
    var fmt by remember { mutableStateOf(s.audioFormat) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = jp.sheet,
        contentColor = jp.text
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            if (info.thumb != null) {
                AsyncImage(
                    model = info.thumb,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(jp.sheetHi)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    info.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    lineHeight = 25.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    color = jp.text
                )
                if (info.creator.isNotBlank()) Text(info.creator, color = jp.textDim, fontSize = 15.sp)
                if (info.seconds > 0) Text("Durasi ${fmtTime(info.seconds)}", color = jp.textDim, fontSize = 15.sp)
            }
            if (info.note != null) Note(info.note, false)

            if (!info.audioOnly) {
                Segment(listOf("Video", "Audio"), if (mode == Mode.VIDEO) 0 else 1) {
                    mode = if (it == 0) Mode.VIDEO else Mode.AUDIO
                }
            }
            if (mode == Mode.VIDEO) {
                Group("Kualitas") {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        heights.forEach { (h, label) -> Pick(label, height == h) { height = h } }
                    }
                }
            } else {
                Group("Format audio") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        audioFormats.forEach { (f, label) -> Pick(label, fmt == f) { fmt = f } }
                    }
                }
            }

            MarkerButton("Unduh", Modifier.fillMaxWidth()) { onGo(mode, height, fmt) }
            Text(
                "Disimpan di ${if (mode == Mode.VIDEO) "Movies" else "Music"}/Jemok Pile",
                color = jp.textDim, fontSize = 13.sp
            )
        }
    }
}

// ---------------------------------------------------------------------- sheet pengaturan

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun SettingsSheet(s: Settings, onDismiss: () -> Unit) {
    val jp = LocalJp.current
    val scope = rememberCoroutineScope()
    var updating by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = jp.sheet,
        contentColor = jp.text
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            Text("Pengaturan", fontFamily = Display, fontSize = 24.sp, color = jp.text)

            Group("Pilihan awal saat tautan dibuka") {
                Segment(listOf("Video", "Audio"), if (s.mode == Mode.VIDEO) 0 else 1) { i ->
                    Engine.updateSettings { it.copy(mode = if (i == 0) Mode.VIDEO else Mode.AUDIO) }
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    heights.forEach { (h, label) ->
                        Pick(label, s.videoHeight == h) { Engine.updateSettings { it.copy(videoHeight = h) } }
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    audioFormats.forEach { (f, label) ->
                        Pick(label, s.audioFormat == f) { Engine.updateSettings { it.copy(audioFormat = f) } }
                    }
                }
            }

            SwitchRow(
                title = "Sematkan sampul dan tag pada audio",
                sub = "Matikan jika konversi audio sering gagal.",
                checked = s.embedTags
            ) { v -> Engine.updateSettings { it.copy(embedTags = v) } }

            Group("Tema") {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Ikuti sistem", "Terang", "Gelap").forEachIndexed { i, label ->
                        Pick(label, s.theme == i) { Engine.updateSettings { it.copy(theme = i) } }
                    }
                }
            }

            Group("Mesin unduh (yt-dlp)") {
                Text(
                    "Versi ${Engine.version()}. Situs sering berubah; kalau unduhan mendadak gagal, perbarui dulu.",
                    color = jp.textDim, fontSize = 14.sp, lineHeight = 20.sp
                )
                SwitchRow(
                    title = "Pakai build nightly",
                    sub = "Dapat perbaikan lebih cepat, tapi kurang teruji.",
                    checked = s.nightly
                ) { v -> Engine.updateSettings { it.copy(nightly = v) } }
                MarkerButton(if (updating) "Memperbarui" else "Perbarui sekarang", enabled = !updating) {
                    scope.launch {
                        updating = true
                        msg = Engine.updateEngine()
                        updating = false
                    }
                }
                msg?.let { Text(it, color = jp.textDim, fontSize = 14.sp, lineHeight = 20.sp) }
            }

            Text(
                "Jemok Pile 1.0. Unduh hanya konten milikmu atau yang memang boleh diunduh.",
                color = jp.textDim, fontSize = 13.sp, lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val jp = LocalJp.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = jp.text)
            Text(sub, color = jp.textDim, fontSize = 13.sp, lineHeight = 18.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = jp.onMarker,
                checkedTrackColor = jp.marker,
                checkedBorderColor = jp.marker,
                uncheckedThumbColor = jp.textDim,
                uncheckedTrackColor = jp.sheetHi,
                uncheckedBorderColor = jp.line
            )
        )
    }
}

// ---------------------------------------------------------------------- buka dan bagikan

private fun openEntry(ctx: Context, e: Entry) {
    val uri = e.resultUri?.let { Uri.parse(it) } ?: return
    val i = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, e.resultMime ?: "*/*")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(i) }.onFailure {
        Toast.makeText(ctx, "Tidak ada aplikasi untuk membuka berkas ini", Toast.LENGTH_SHORT).show()
    }
}

private fun shareEntry(ctx: Context, e: Entry) {
    val uri = e.resultUri?.let { Uri.parse(it) } ?: return
    val i = Intent(Intent.ACTION_SEND)
        .setType(e.resultMime ?: "*/*")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { ctx.startActivity(Intent.createChooser(i, "Bagikan")) }.onFailure {
        Toast.makeText(ctx, "Berkas tidak bisa dibagikan", Toast.LENGTH_SHORT).show()
    }
}
