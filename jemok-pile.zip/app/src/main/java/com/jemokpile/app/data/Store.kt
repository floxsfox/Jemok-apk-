package com.jemokpile.app.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray

/** Penyimpanan sederhana (SharedPreferences) untuk daftar unduhan dan pengaturan. */
object Store {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("jemokpile", Context.MODE_PRIVATE)
    }

    fun loadEntries(): List<Entry> = runCatching {
        val a = JSONArray(sp.getString("entries", "[]"))
        (0 until a.length()).map { Entry.fromJson(a.getJSONObject(it)) }
    }.getOrDefault(emptyList())

    fun saveEntries(list: List<Entry>) {
        val a = JSONArray()
        list.take(80).forEach { a.put(it.toJson()) }
        sp.edit().putString("entries", a.toString()).apply()
    }

    fun loadSettings(): Settings = Settings(
        mode = if (sp.getString("mode", "VIDEO") == "AUDIO") Mode.AUDIO else Mode.VIDEO,
        videoHeight = sp.getInt("height", 0),
        audioFormat = sp.getString("afmt", "mp3") ?: "mp3",
        embedTags = sp.getBoolean("tags", true),
        theme = sp.getInt("theme", 0),
        nightly = sp.getBoolean("nightly", false)
    )

    fun saveSettings(s: Settings) {
        sp.edit()
            .putString("mode", s.mode.name)
            .putInt("height", s.videoHeight)
            .putString("afmt", s.audioFormat)
            .putBoolean("tags", s.embedTags)
            .putInt("theme", s.theme)
            .putBoolean("nightly", s.nightly)
            .apply()
    }
}
