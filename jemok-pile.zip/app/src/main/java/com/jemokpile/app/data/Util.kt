package com.jemokpile.app.data

private val urlRegex = Regex("""https?://[^\s<>"']+""")

/** Ambil tautan pertama dari teks (teks hasil "Bagikan" biasanya berisi judul + tautan). */
fun extractUrl(text: String): String? =
    urlRegex.find(text)?.value?.trimEnd('.', ',', ')', ']', '!', '?')

fun fmtTime(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
